<body>
        <div class="category-filter">
            <a href="<?php echo e(route('catalog', $item)); ?>"><?php echo e($item->title); ?></a>
        </div>
        <?php if(auth()->guard()->check()): ?>
            <?php if(auth()->user()->role == 'продавец'): ?>
                <form method="post" action="<?php echo e(route('removeCategory', $item->id)); ?>">
                    <?php echo csrf_field(); ?>
                    <button type="submit" class="btn btn-success">Удалить категорию</button>
                </form>

                <button
                    onclick="window.location.href = '<?php echo e(route('editCategory', $item->id)); ?>'"
                    type="button"
                    class="btn btn-warning">
                    Редактировать категорию
                </button>
            <?php endif; ?>
        <?php endif; ?>

<script type="module" src="https://unpkg.com/ionicons@7.1.0/dist/ionicons/ionicons.esm.js"></script>
<script nomodule src="https://unpkg.com/ionicons@7.1.0/dist/ionicons/ionicons.js"></script>
</body>
<?php /**PATH C:\work\market\resources\views/components/category.blade.php ENDPATH**/ ?>