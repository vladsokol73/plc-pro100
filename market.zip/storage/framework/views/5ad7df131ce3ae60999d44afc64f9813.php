<?php $__env->startSection("title"); ?>
    Корзина
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="top-bar">
        <a href="<?php echo e(route('catalog')); ?>">
            <i class="fas fa-arrow-left"></i>
        </a>
        <span>Продолжить покупки</span>
    </div>

    <?php if(count($products)): ?>
        <div class="bag">
            <p class="bag-head"><span style="text-transform: uppercase">В вашей корзине</span> - <?php echo e(count($products)); ?>

                товар(ов)</p>
        </div>
        <?php
            $basketCost = 0;
        ?>

        <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php
                $count = 1;
                $itemPrice = $product->price * $count;
                $basketCost = $basketCost + $itemPrice;
            ?>
            <div class="cart-product">
            <section class="product-details">
                <div class="image-slider">
                    <img src="<?php echo e($product->makeThumbnail('345x320')); ?>" alt="<?php echo e($product->title); ?>">
                </div>

                <div class="details">
                    <h2 class="product-brand"><?php echo e($product->title); ?></h2>
                    <p class="product-short-des"><?php echo e($product->description); ?></p>
                    <p class="product-sub-heading">Спецификация</p>
                    <p>Тип: <?php $__currentLoopData = $product->categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php echo e($category->title); ?>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></p>
                    <p>Производитель: <?php echo e($product->brand->title); ?></p>









                    <span class="product-price"><?php echo e($product->price); ?> &#8381; </span>
                    <form action="<?php echo e(route('basketRemove', ['id' => $product->id])); ?>"
                          method="post" class="basket-remove">
                        <?php echo csrf_field(); ?>
                        <button type="submit" class="btn btn-remove">Удалить</button>
                    </form>
                </div>
            </section>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <div class="bag-total">
            <div class="delivery">
                <p class="small">Доставка: не входит в стоимость<br>
            </div>
            <div class="total">
                <h3>Итого: <?php echo e($basketCost); ?> &#8381;</h3>
            </div>

            <?php if(auth()->guard()->check()): ?>
                <button onclick="window.location='<?php echo e(route('checkout')); ?>'" class="btn-go-checkout">
                    <i class="fas fa-lock"></i>
                    <span>Оформить заказ</span>
                </button>
            <?php elseif(auth()->guard()->guest()): ?>
                <button onclick="window.location='<?php echo e(route('login')); ?>'" class="btn-go-checkout">
                    <i class="fas fa-lock"></i>
                    <span>Оформить заказ</span>
                </button>
            <?php endif; ?>
        </div>
    <?php else: ?>
        <div class="basket-clear">
        <p>Ваша корзина пуста</p>
        </div>
    <?php endif; ?>
    <div class="help">
        <p>Нужна помощь? Звоните бесплатно <a href="tel:+79297949431">+7(929)794-94-31</a></p>
    </div>
<?php $__env->stopSection(); ?>

<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.3.1/css/all.css"
      integrity="sha384-mzrmE5qonljUremFsqc01SB46JvROS7bZs3IO2EmfFsd15uHvIt+Y8vEf7N7fWAU" crossorigin="anonymous">

<?php echo $__env->make("layouts.app", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\PHPStormProjects\market\resources\views/basket/index.blade.php ENDPATH**/ ?>