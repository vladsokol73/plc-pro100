<li class="mix">
    <div class="product-card">
        <div class="product-image">

            <a href="<?php echo e(route('product', $item)); ?>"><img src="<?php echo e($item->makeThumbnail('345x320')); ?>" alt="<?php echo e($item->title); ?>" class="product-thumb"></a>
            <form method="post" action="<?php echo e(route('basketAdd', ['id' => $item->id])); ?>" class="imdiz-product__buy-form">
                <?php echo csrf_field(); ?>
                <?php if(auth()->guard()->check()): ?>
                    <?php if(auth()->user()->role != 'продавец'): ?>
                        <button type="submit" class="card-btn">В корзину</button>
                    <?php endif; ?>
                <?php elseif(auth()->guard()->guest()): ?>
                    <button type="submit" class="card-btn">В корзину</button>
                <?php endif; ?>
            </form>

            <?php if(auth()->guard()->check()): ?>
                <?php if(auth()->user()->role == 'продавец'): ?>
                    <button
                        onclick="window.location.href = '<?php echo e(route('editProduct', $item->id)); ?>'"
                        type="button"
                        class="card-btn">
                        Редактировать товар
                    </button>
                <?php endif; ?>
            <?php endif; ?>
        </div>
        <div class="product-info">
            <h2 class="product-brand">Название: <?php echo e($item->title); ?></h2>
            <p class="product-short-des">артикул: <?php echo e($item->article); ?></p>
            <p class="product-short-des">производитель: <?php echo e($item->brand->title); ?></p>
            <span class="price"><?php echo e($item->price); ?> &#8381;</span>

            <?php if(auth()->guard()->check()): ?>
                <?php if(auth()->user()->role == 'продавец'): ?>
                    <form method="post" action="<?php echo e(route('removeProduct', $item->id)); ?>">
                        <?php echo csrf_field(); ?>
                        <button type="submit" class="card-btn2">Удалить товар</button>
                    </form>
                <?php endif; ?>
            <?php endif; ?>
        </div>
    </div>
</li>
<?php /**PATH F:\PHPStormProjects\market\resources\views/components/product.blade.php ENDPATH**/ ?>