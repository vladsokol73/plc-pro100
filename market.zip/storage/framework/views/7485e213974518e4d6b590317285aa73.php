<?php $__env->startSection("title", 'Админ панель'); ?>

<?php $__env->startSection("content"); ?>
    <body>
    <?php if(auth()->guard()->check()): ?>
        <?php if(auth()->user()->role == "продавец"): ?>
            <div class="buttons">
            <button
                onclick="window.location.href = '<?php echo e(route('addProduct')); ?>'"
                type="button"
                class="btn-admin">
                Добавить товар
            </button>

            <button
                onclick="window.location.href = '<?php echo e(route('addBrand')); ?>'"
                type="button"
                class="btn-admin">
                Добавить производителя
            </button>

            <button
                onclick="window.location.href = '<?php echo e(route('addCategory')); ?>'"
                type="button"
                class="btn-admin">
                Добавить категорию
            </button>
            </div>

            <div class="buttons">
                <button
                    onclick="window.location.href = '<?php echo e(route('showBrands')); ?>'"
                    type="button"
                    class="btn-admin">
                    Все производители
                </button>

                <button
                    onclick="window.location.href = '<?php echo e(route('showCategories')); ?>'"
                    type="button"
                    class="btn-admin">
                    Все категории
                </button>

                <button
                    onclick="window.location.href = '<?php echo e(route('sellerContacts')); ?>'"
                    type="button"
                    class="btn-admin">
                    Обратная связь
                </button>
            </div>
        <?php endif; ?>
    <?php endif; ?>
    </body>
<?php $__env->stopSection(); ?>

<?php echo $__env->make("layouts.app", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\PHPStormProjects\market\resources\views/catalog/seller-catalog.blade.php ENDPATH**/ ?>