<?php $__env->startSection("title", 'Обратная связь'); ?>

<?php $__env->startSection("content"); ?>
    <body>
    <div>
        <h1 class="page-title">Обратная связь</h1>
        <div class="contacts">
            <?php echo $__env->renderEach('components.contact', $contacts, 'item'); ?>
        </div>
    </div>
    </body>
<?php $__env->stopSection(); ?>

<?php echo $__env->make("layouts.app", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\PHPStormProjects\market\resources\views/profile/contact.blade.php ENDPATH**/ ?>