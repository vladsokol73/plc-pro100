<?php $__env->startSection("title"); ?>
    Ваши продажи
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <h1>Ваши продажи</h1>

    <?php if(count($products)): ?>
        <table class="table table-bordered" style="color: #ffffff">
            <tr>
                <th>№</th>
                <th width="22%">Детали</th>
                <th width="22%">Название</th>
                <th width="22%">Цена</th>
            </tr>
            <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($loop->iteration); ?></td>
                    <td>
                        <a href="<?php echo e(route('product', $product)); ?>">
                            Подробнее
                        </a>
                    </td>
                    <td><?php echo e($product->title); ?></td>
                    <td><?php echo e($product->price); ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </table>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\work\market\resources\views/profile/seller.blade.php ENDPATH**/ ?>