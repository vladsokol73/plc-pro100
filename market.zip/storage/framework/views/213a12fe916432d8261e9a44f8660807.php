<?php $__env->startSection("title"); ?>
    Редактирование брэнда
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="container">
        <h1 class="mb-4">Редактировать брэнд</h1>
        <form method="post" action="<?php echo e(route('editBrandSubmit', $brand->id)); ?>" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <div class="form-group" style="margin-top: 10px">
                <input type="text" class="form-control" name="title" placeholder="Название товара"
                       required minlength="3" maxlength="35" value="<?php echo e($brand->title); ?>">
            </div>
            <div class="form-group" style="margin-top: 10px">
                <div>Новая картинка</div>
                <input style="margin-top: 10px" type="file" class="form-control-file" name="thumbnail" id="thumbnail" multiple accept="image/*,image/jpeg"
                       maxlength="255" value="<?php echo e(old('thumbnail') ?? ''); ?>">
            </div>
            <button type="submit" class="btn btn-success">Сохранить</button>
        </form>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make("layouts.app", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\PHPStormProjects\market\resources\views/brand/edit.blade.php ENDPATH**/ ?>