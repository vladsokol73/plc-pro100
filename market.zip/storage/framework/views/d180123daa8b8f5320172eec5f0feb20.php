<?php $__env->startSection("title", $user->name ?? 'Каталог'); ?>

<?php $__env->startSection("content"); ?>
    <body>

    <main class="cd-main-content">
        <div class="cd-tab-filter-wrapper">
            <div class="cd-tab-filter">
                <ul class="cd-filters">
                    <div class="total">
                        Найдено: <?php echo e($products->total()); ?> товаров

                        <div class="sort" x-data="{}">
                            <span>Сортировать</span>

                            <form x-ref="sortForm" action="<?php echo e(route('catalog', $category)); ?>">
                                <select name="sort" x-on:change="$refs.sortForm.submit()" class="form-select">
                                    <option value="" class="text-dark">по умолчанию</option>
                                    <option <?php if(request('sort') === 'price'): echo 'selected'; endif; ?> value="price" class="text-dark">от
                                        дешевых к
                                        дорогим
                                    </option>
                                    <option <?php if(request('sort') === '-price'): echo 'selected'; endif; ?> value="-price" class="text-dark">от
                                        дорогих
                                        к
                                        дешевым
                                    </option>
                                    <option <?php if(request('sort') === 'title'): echo 'selected'; endif; ?> value="title" class="text-dark">
                                        наименованию
                                    </option>
                                </select>
                            </form>
                        </div>
                    </div>
                </ul> <!-- cd-filters -->
            </div> <!-- cd-tab-filter -->
        </div> <!-- cd-tab-filter-wrapper -->
        <ul class="step">
            <li><a href="<?php echo e(route('home')); ?>">Главная</a></li>
            <li><a href="<?php echo e(route('catalog')); ?>">Каталог</a></li>
            <?php if($category->exists): ?>
                <?php if($category->parent_id != null): ?>
                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($item->id == $category->parent_id): ?>
                            <li><a href="<?php echo e(route('catalog', $item)); ?>"><?php echo e($item->title); ?></a></li>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
                <li>
                    <span><?php echo e($category->title); ?></span>
                </li>
            <?php endif; ?>
        </ul>
        <!-- ВСЕ ПРОДУКТЫ -->
        <section class="cd-gallery">
            <ul>
                <?php echo $__env->renderEach('components.product', $products, 'item'); ?>
                <li class="gap"></li>
                <li class="gap"></li>
                <li class="gap"></li>
            </ul>
            <div class="cd-fail-message"><p>Не нашли что искали?<a href="<?php echo e(route('contact')); ?>"> Напишите нам</a> и мы рассчитаем стоимость нужного вам товара.</p></div>
            <?php echo e($products->withQueryString()->links()); ?>

        </section> <!-- cd-gallery -->

        <div class="cd-filter">
            <form action="<?php echo e(route('catalog', $category)); ?>" method="get">

                <div class="cd-filter-block">
                    <h4>Цена</h4>
                    <div class="cd-filter-content">
                        <span class="from">От, ₽</span>
                        <span class="to">До, ₽</span>
                        <div class="cost-filter">
                            <input name="filters[price][from]"
                                   value="<?php echo e(request('filters.price.from', 0)); ?>"
                                   type="number"
                                   class="price-from"
                                   placeholder="От">
                            <span>-</span>
                            <input name="filters[price][to]"
                                   value="<?php echo e(request('filters.price.to', 999999)); ?>"
                                   type="number"
                                   class="price-to"
                                   placeholder="До">
                        </div>
                    </div> <!-- cd-filter-content -->
                </div> <!-- cd-filter-block -->

                <div class="cd-filter-block">
                    <h4>Бренды</h4>
                    <ul class="cd-filter-content cd-filters list">
                        <?php $__currentLoopData = $brands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $brand): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li>
                                <input
                                        class="filter"
                                        name="filters[brands][<?php echo e($brand->id); ?>]"
                                        value="<?php echo e($brand->id); ?>"
                                        type="checkbox"
                                        <?php if(request('filters.brands.'.$brand->id)): echo 'checked'; endif; ?>
                                        id="filters-brands-<?php echo e($brand->id); ?>">

                                <label for="filters-brands-<?php echo e($brand->id); ?>" class="checkbox-label">
                                    <?php echo e($brand->title); ?>

                                </label>
                            </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul> <!-- cd-filter-content -->
                </div> <!-- cd-filter-block -->

                <div>
                    <button class="button-filter" type="submit">Поиск</button>
                </div>
                <?php if(@request('filters')): ?>
                    <div class="btn-fresh">
                        <a href="<?php echo e(route('catalog', $category)); ?>">Сбросить фильтры</a>
                    </div>
                <?php endif; ?>
            </form>

            <a href="#0" class="cd-close">Закрыть</a>
        </div> <!-- cd-filter -->

        <a href="#0" class="cd-filter-trigger">Фильтры</a>
    </main> <!-- cd-main-content -->
    <script src="/js/jquery-2.1.1.js"></script>
    <script src="/js/jquery.mixitup.min.js"></script>
    <script src="/js/main.js"></script> <!-- Resource jQuery -->
    </body>
<?php $__env->stopSection(); ?>

<?php echo $__env->make("layouts.catalog", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\PHPStormProjects\market\resources\views/catalog/catalog.blade.php ENDPATH**/ ?>