<?php $__env->startSection("title"); ?>
    Ваши заказы
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <h1>Ваши заказы</h1>

    <?php if(count($orders)): ?>
        <table class="table table-bordered" style="color: #ffffff">
            <tr>
                <th>№</th>
                <th width="22%">Детали</th>
                <th width="22%">Имя, Фамилия</th>
                <th width="22%">Адрес почты</th>
                <th width="22%">Номер телефона</th>
            </tr>
            <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($loop->iteration); ?></td>
                    <td>
                        <a href="<?php echo e(route('userOrder', $order)); ?>">
                            Подробнее
                        </a>
                    </td>
                    <td><?php echo e($order->name); ?></td>
                    <td><a href="mailto:<?php echo e($order->email); ?>"><?php echo e($order->email); ?></a></td>
                    <td><?php echo e($order->phone); ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </table>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\work\market\resources\views/profile/user.blade.php ENDPATH**/ ?>