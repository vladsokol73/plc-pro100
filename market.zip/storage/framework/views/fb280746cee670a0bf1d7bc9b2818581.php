<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag; ?>
<?php foreach($attributes->onlyProps([
    "type" => "text",
    "value" => "",
    "isError" => false
]) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $attributes = $attributes->exceptProps([
    "type" => "text",
    "value" => "",
    "isError" => false
]); ?>
<?php foreach (array_filter(([
    "type" => "text",
    "value" => "",
    "isError" => false
]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>

<input type="<?php echo e($type); ?>" value="<?php echo e($value); ?>" <?php echo e($attributes
 ->class([
     "_is-error" => $isError
     ])); ?>>
<?php /**PATH E:\PHPStormProjects\market\resources\views/components/forms/text-input.blade.php ENDPATH**/ ?>