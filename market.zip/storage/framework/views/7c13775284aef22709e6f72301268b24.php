<?php $__env->startSection("title", 'Бренды'); ?>

<?php $__env->startSection("content"); ?>
    <body>
    <div>
        <h1 class="page-title">Все бренды</h1>
        <?php echo $__env->renderEach('components.brand', $brands, 'item'); ?>
    </div>
    </body>
<?php $__env->stopSection(); ?>

<?php echo $__env->make("layouts.app", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\PHPStormProjects\market\resources\views/catalog/brands.blade.php ENDPATH**/ ?>