<?php echo '<?xml version="1.0" encoding="UTF-8"?>'; ?>

<sitemapindex xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">
    <sitemap>
        <loc><?php echo e(url('sitemap/products')); ?></loc>
        <lastmod><?php echo e($product->updated_at->toAtomString()); ?></lastmod>
    </sitemap>
    <sitemap>
        <loc><?php echo e(url('sitemap/categories')); ?></loc>
        <lastmod><?php echo e($category->updated_at->toAtomString()); ?></lastmod>
    </sitemap>
</sitemapindex>
<?php /**PATH E:\PHPStormProjects\market\resources\views/sitemap/index.blade.php ENDPATH**/ ?>