<div class="mt-3 text-pink text-xxs xs:text-xs">
    <?php echo e($slot); ?>

</div>
<?php /**PATH F:\PHPStormProjects\market\resources\views/components/forms/error.blade.php ENDPATH**/ ?>