<body>
<option value="<?php echo e($item->id); ?>"><?php echo e($item->title); ?></option>
</body>
<?php /**PATH C:\work\market\resources\views/components/brandradio.blade.php ENDPATH**/ ?>