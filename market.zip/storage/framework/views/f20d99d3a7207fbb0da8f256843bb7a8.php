<?php $__env->startSection("title"); ?>
    Профиль
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <h1 class="profile-title">Ваши продажи</h1>

    <div>
        <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="orders">
                <h1><?php echo e($order->created_at); ?></h1>
                <a href="<?php echo e(route('userOrder', $order)); ?>">Подробнее</a>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\PHPStormProjects\market\resources\views/profile/seller.blade.php ENDPATH**/ ?>