Тестовое письмо
<?php /**PATH E:\PHPStormProjects\market\resources\views/mail.blade.php ENDPATH**/ ?>