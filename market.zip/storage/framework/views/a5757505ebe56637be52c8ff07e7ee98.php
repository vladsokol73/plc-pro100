<?php $__env->startSection("title", $user->name ?? 'Каталог'); ?>

<?php $__env->startSection("content"); ?>
    <body>
    <?php if(auth()->guard()->check()): ?>
        <?php if(auth()->user()->role == "продавец"): ?>
            <button
                onclick="window.location.href = '<?php echo e(route('addProduct')); ?>'"
                type="button"
                class="btn btn-warning">
                Добавить товар
            </button>

            <button
                onclick="window.location.href = '<?php echo e(route('addBrand')); ?>'"
                type="button"
                class="btn btn-warning">
                Добавить производителя
            </button>

            <button
                onclick="window.location.href = '<?php echo e(route('addCategory')); ?>'"
                type="button"
                class="btn btn-warning">
                Добавить категорию
            </button>

            <div class="container">
                    <div class="cards">
                        <?php echo $__env->renderEach('components.product', $products, 'item'); ?>
                    </div>
            </div>

            <div class="container1">
                    <div class="cards1">
                        <?php echo $__env->renderEach('components.brand', $brands, 'item'); ?>
                    </div>
            </div>

            <div class="container1">
                    <div class="cards1">
                        <?php echo $__env->renderEach('components.category', $category, 'item'); ?>
                    </div>
            </div>
        <?php endif; ?>
    <?php endif; ?>

    <div class="paginator">
        <?php echo e($products->withQueryString()->links('pagination::bootstrap-4')); ?>

    </div>
    </body>
<?php $__env->stopSection(); ?>

<?php echo $__env->make("layouts.app", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\work\market\resources\views/catalog/seller-catalog.blade.php ENDPATH**/ ?>