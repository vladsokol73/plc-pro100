<body>
<div class="contact">

    <p class="contact-p">Создано: <?php echo e($item->created_at); ?></p>

    <p class="contact-p">Имя: <?php echo e($item->name); ?></p>

    <p class="contact-p">Почта: <?php echo e($item->email); ?></p>

    <p class="contact-p">Телефон: <?php echo e($item->phone); ?></p>

    <p class="contact-p">Сообщение: <?php echo e($item->message); ?></p>

    <form method="post" action="<?php echo e(route('removeContact', $item->id)); ?>">
        <?php echo csrf_field(); ?>
        <button type="submit" class="btn-admin">Удалить</button>
    </form>
</div>
</body>
<?php /**PATH F:\PHPStormProjects\market\resources\views/components/contact.blade.php ENDPATH**/ ?>