<button type="submit">
    <?php echo e($slot); ?>

</button>
<?php /**PATH C:\work\market\resources\views/components/forms/primary-button.blade.php ENDPATH**/ ?>