<?php $__env->startSection("title", 'Категории'); ?>

<?php $__env->startSection("content"); ?>
    <body>
    <div>
        <?php echo $__env->renderEach('components.category', $categories, 'item'); ?>
    </div>
    </body>
<?php $__env->stopSection(); ?>

<?php echo $__env->make("layouts.app", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\PHPStormProjects\market\resources\views/catalog/categories.blade.php ENDPATH**/ ?>