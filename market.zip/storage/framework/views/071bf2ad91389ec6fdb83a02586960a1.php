<header>
<nav class="navbar">
    <span class="burger">&#9776;</span>
    <div class="nav phone-hide">
        <a href="<?php echo e(route('home')); ?>"><img src="/storage/images/logotip.jpg" class="brand-logo" alt=""></a>
        <div class="nav-items">
            <div class="search">
                <form class="search" action="<?php echo e(route('catalog')); ?>">
                    <input id="search" name="s" value="<?php echo e(request('s')); ?>" type="search" class="search-box"
                           placeholder="поиск по названию, артиклу">
                    <button class="search-btn" type="submit">найти</button>
                </form>
            </div>
            <?php if(auth()->guard()->check()): ?>
                <?php if(auth()->user()->role == "покупатель"): ?>
                    <a href="<?php echo e(route('basket')); ?>"><img src="/storage/images/cart.png" alt=""></a>
                    <a href="<?php echo e(route('catalog')); ?>">Каталог товаров</a>
                <?php else: ?>
                    <a href="<?php echo e(route('sellerCatalog')); ?>">Просмотр товаров</a>
                <?php endif; ?>
            <?php endif; ?>
            <?php if(auth()->guard()->guest()): ?>
                <a href="<?php echo e(route('basket')); ?>"><img src="/storage/images/cart.png" alt=""></a>
                <a href="<?php echo e(route('catalog')); ?>">Каталог товаров</a>
            <?php endif; ?>

            <?php if(auth()->guard()->check()): ?>
                <?php if(auth()->user()->role == "покупатель"): ?>
                    <a href="<?php echo e(route('userOrders')); ?>"><img src="/storage/images/user.png" alt=""></a>
                <?php else: ?>
                    <a href="<?php echo e(route('sellerProfile')); ?>"><img src="/storage/images/user.png" alt=""></a>

                <?php endif; ?>
                <form id="logout" method="post" action="<?php echo e(route("logout")); ?>" class="button-logout">
                    <?php echo csrf_field(); ?>
                    <a href="#" onclick="document.getElementById('logout').submit()">
                        <img src="/storage/images/logout.png" alt="">
                    </a>
                </form>
            <?php elseif(auth()->guard()->guest()): ?>
                <a href="<?php echo e(route('login')); ?>">Войти</a>
                <a href="<?php echo e(route('register')); ?>">Зарегистрироваться</a>
            <?php endif; ?>
        </div>
    </div>
</nav>

<ul class="links-container">
    <li class="link-item"><a href="#" class="link">Категории</a></li>
    <li class="link-item"><a href="#" class="link">Бренды</a></li>
    <li class="link-item"><a href="#" class="link">Способы покупки</a></li>
    <li class="link-item"><a href="<?php echo e(route('contact')); ?>" class="link">Задать вопрос</a></li>
</ul>
</header>
<?php /**PATH C:\work\market\resources\views/inc/header.blade.php ENDPATH**/ ?>