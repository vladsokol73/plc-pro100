<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="/css/home.css">
    <title><?php echo $__env->yieldContent("title"); ?></title>
</head>

</html>

<?php $__env->startSection("title"); ?>
    Главная
<?php $__env->stopSection(); ?>
<?php echo $__env->make("inc.header", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->startSection("content"); ?>
    <body>
    <section class="home">
        <div class="home-detail">
            <h3>PLC_Pro-100</h3>
            <h3>Интернет Магазин Продуктов Промышленной Автоматизации</h3>
            <p>Мы-поставщик новых деталей для автоматизации, поставляем промышленное электронное оборудование и
                компоненты для его ремонта в России.
                Наша компания помогает решить проблему в максимально короткие сроки.</p>
            <button onclick="Livewire.emit('openModal', 'contact-modal')">Написать нам</button>
        </div>
    </section>
    </body>
    <?php echo $__env->make("inc.footer", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>


<?php echo $__env->yieldContent("content"); ?>


<?php /**PATH C:\work\market\resources\views/home.blade.php ENDPATH**/ ?>