<?php $__env->startSection("title"); ?>
    Корзина
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <?php if(count($products)): ?>
        <h1>Ваша корзина</h1>
        <?php
            $basketCost = 0;
        ?>
        <table class="table table-bordered" style="color: #0bcebf">
            <tr>
                <th>№</th>
                <th>Наименование</th>
                <th>Цена</th>
            </tr>
            <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php
                    $itemPrice = $product->price;
                    $basketCost = $basketCost + $itemPrice;
                ?>
                <tr>
                    <td><?php echo e($loop->iteration); ?></td>
                    <td>
                        <a href="<?php echo e(route('product', $product)); ?>"><?php echo e($product->title); ?></a>
                    </td>
                    <td><?php echo e($itemPrice); ?></td>
                    <td>
                        <form action="<?php echo e(route('basketRemove', ['id' => $product->id])); ?>"
                              method="post" class="form-inline">
                            <?php echo csrf_field(); ?>
                            <button type="submit" class="btn btn-success">Удалить</button>
                        </form></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <th colspan="2" class="text-right">Итого</th>
                <th><?php echo e($basketCost); ?></th>
            </tr>
        </table>
        <?php if(auth()->guard()->check()): ?>
        <a href="<?php echo e(route('checkout')); ?>">Оформить заказ</a>
        <?php elseif(auth()->guard()->guest()): ?>
            <a href="<?php echo e(route('login')); ?>">Оформить заказ</a>
        <?php endif; ?>
    <?php else: ?>
        <p>Ваша корзина пуста</p>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make("layouts.app", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\work\market\resources\views/basket/index.blade.php ENDPATH**/ ?>