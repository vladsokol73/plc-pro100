<?php $__env->startSection("title"); ?>
    Оформление заказа
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <form method="post" class="checkout" action="<?php echo e(route('saveOrder')); ?>">
        <h1 class="mb-4">Оформить заказ</h1>
        <?php echo csrf_field(); ?>
        <div class="form-group">
            <i class="fa fa-user icon"></i>
            <input type="text" class="form-control" name="name" placeholder="Имя"
                   required maxlength="255" value="<?php echo e(old('name') ?? ''); ?>">
        </div>
        <div class="form-group">
            <i class="fa fa-envelope"></i>
            <input type="email" class="form-control" name="email" placeholder="Почта"
                   required maxlength="255" value="<?php echo e(old('email') ?? ''); ?>">
        </div>
        <div class="form-group">
            <i class="fa-solid fa-phone"></i>
            <input type="number" class="form-control" name="phone" placeholder="Телефон"
                   required maxlength="255" value="<?php echo e(old('phone') ?? ''); ?>">
        </div>
        <div class="form-group">
            <i class="fa-solid fa-location-dot"></i>
            <input type="text" class="form-control" name="address" placeholder="Адрес доставки"
                   required maxlength="255" value="<?php echo e(old('address') ?? ''); ?>">
        </div>
        <div class="form-group">
            <textarea class="form-control" name="comment" placeholder="Комментарий"
                      maxlength="255"><?php echo e(old('comment') ?? ''); ?></textarea>
        </div>
        <div class="form-group">
            <button type="submit" class="btn checkout-submit">Оформить</button>
        </div>
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make("layouts.app", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\PHPStormProjects\market\resources\views/basket/checkout.blade.php ENDPATH**/ ?>