<?php echo '<?xml version="1.0" encoding="UTF-8"?>'; ?>
<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">
    <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <url>
            <loc><?php echo e(url("/")); ?><?php echo e("/product/"); ?><?php echo e($product->slug); ?></loc>
            <lastmod><?php echo e($product->updated_at->toAtomString()); ?></lastmod>
            <changefreq>monthly</changefreq>
            <priority>1.0</priority>
        </url>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</urlset>
<?php /**PATH E:\PHPStormProjects\market\resources\views/sitemap/products.blade.php ENDPATH**/ ?>