<div>
    <h1>Обратная связь номер: <?php echo e($contactNum); ?></h1>
    <h1>Создана: <?php echo e($contactDate); ?></h1>
    <div>
        <h2>Имя: <?php echo e($contactName); ?></h2>
        <h2>Почта: <?php echo e($contactMail); ?></h2>
        <h2>Телефон: <?php echo e($contactPhone); ?></h2>
        <h2>Сообщение: <?php echo e($contactMessage); ?></h2>
    </div>
</div>
<?php /**PATH E:\PHPStormProjects\market\resources\views/contact-email.blade.php ENDPATH**/ ?>