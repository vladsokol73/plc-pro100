<button class="auth-btn" type="submit">
    <?php echo e($slot); ?>

</button>
<?php /**PATH F:\PHPStormProjects\market\resources\views/components/forms/primary-button.blade.php ENDPATH**/ ?>