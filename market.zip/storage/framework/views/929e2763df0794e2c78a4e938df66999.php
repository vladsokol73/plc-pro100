<?php $__env->startSection("title"); ?>
    Редактирование категории
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <h1 class="mb-4">Редактировать категорию</h1>
    <div class="container">
        <form method="post" action="<?php echo e(route('editCategorySubmit', $category->id)); ?>" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <div class="form-group" style="margin-top: 10px">
                <input type="text" class="form-control" name="title" placeholder="название категории"
                       required minlength="3" maxlength="22" value="<?php echo e($category->title); ?>">
            </div>

            <div class="form-group">
                <p>Категория-родитель</p>
                <select id="parent_id" name="parent_id">
                    <option value="<?php echo e($category->parent_id); ?>">Прежнее</option>
                    <option value="<?php echo e(null); ?>">Отсутствует</option>
                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($item->parent_id == null and $category->parent_id != $item->id): ?>
                        <option value="<?php echo e($item->id); ?>"><?php echo e($item->title); ?></option>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>

            <button type="submit" class="btn btn-success">Сохранить</button>
        </form>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make("layouts.app", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\PHPStormProjects\market\resources\views/category/edit.blade.php ENDPATH**/ ?>