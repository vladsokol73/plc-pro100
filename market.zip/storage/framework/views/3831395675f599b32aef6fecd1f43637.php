<body>
        <div class="categories">
            <a class="category-filter" href="<?php echo e(route('catalog', $item)); ?>"><?php echo e($item->title); ?></a>
        <?php if(auth()->guard()->check()): ?>
            <?php if(auth()->user()->role == 'продавец'): ?>
                <form method="post" action="<?php echo e(route('removeCategory', $item->id)); ?>">
                    <?php echo csrf_field(); ?>
                    <button type="submit" class="btn-admin">Удалить категорию</button>
                </form>

                <button
                    onclick="window.location.href = '<?php echo e(route('editCategory', $item->id)); ?>'"
                    type="button"
                    class="btn-admin">
                    Редактировать категорию
                </button>
            <?php endif; ?>
        <?php endif; ?>
        </div>

<script type="module" src="https://unpkg.com/ionicons@7.1.0/dist/ionicons/ionicons.esm.js"></script>
<script nomodule src="https://unpkg.com/ionicons@7.1.0/dist/ionicons/ionicons.js"></script>
</body>
<?php /**PATH F:\PHPStormProjects\market\resources\views/components/category.blade.php ENDPATH**/ ?>