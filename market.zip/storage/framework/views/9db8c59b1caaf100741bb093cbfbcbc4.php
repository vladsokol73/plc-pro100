<footer>
    <p class="footer-title">О компании</p>
    <p class="info">PLC-Pro не является уполномоченным дистрибьютором или представителем производителя. Размещенные на этом сайте торговые марки являются собственностью их соответствующих владельцев</p>
    <p class="info">Наша почта - plc-pro100@mail.ru</p>
    <p class="info">Телефон - </p>
    <div class="footer-social-container">
        <div>
            <a href="#" class="social-link">Политика конфиденциальности</a>
            <a href="#" class="social-link">Согласие на обработку персональных данных</a>
        </div>
        <div>



        </div>
    </div>
    <p class="footer-credit">© 2023 PLC_Pro-100</p>
</footer>
<?php /**PATH C:\work\market\resources\views/inc/footer.blade.php ENDPATH**/ ?>