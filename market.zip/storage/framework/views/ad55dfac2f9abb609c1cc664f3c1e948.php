<footer>
    <p class="footer-title">О компании</p>
    <p class="info">PLC-Pro не является уполномоченным дистрибьютором или представителем производителя. Размещенные на этом сайте торговые марки являются собственностью их соответствующих владельцев</p>
    <p class="info">Наша почта - <a href="mailto:burdin100@mail.ru">burdin100@mail.ru</a> <a href="mailto:burdin100@outlook.com">burdin100@outlook.com</a></p>
    <p class="info">Телефон <a href="tel:+79297949431">+7(929)794-94-31</a></p>
    <div class="footer-social-container">
        <div class="left">
            <a href="<?php echo e(route('police')); ?>" class="social-link">Политика конфиденциальности</a>
            <a href="<?php echo e(route('agreement')); ?>" class="social-link">Согласие на обработку персональных данных</a>
        </div>
        <div>
            
            
            
        </div>
    </div>
    <p class="footer-credit">© 2024 PLC_Pro-100</p>
</footer>
<?php /**PATH E:\PHPStormProjects\market\resources\views/inc/footer.blade.php ENDPATH**/ ?>