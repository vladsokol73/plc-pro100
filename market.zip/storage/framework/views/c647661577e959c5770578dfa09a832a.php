<button class="auth-btn" type="submit">
    <?php echo e($slot); ?>

</button>
<?php /**PATH E:\PHPStormProjects\market\resources\views/components/forms/primary-button.blade.php ENDPATH**/ ?>