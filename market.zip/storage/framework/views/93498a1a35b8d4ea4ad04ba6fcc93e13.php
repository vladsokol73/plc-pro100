<body>
<div class="brand">
    <form action="<?php echo e(route('catalog')); ?>" method="get">
        <?php if($item->thumbnail != null): ?>
            <?php if(auth()->guard()->check()): ?>
                <?php if(auth()->user()->role != 'продавец'): ?>
                    <div class="image">
                        <button class="button-filter" type="submit">
                            <input
                                class="filter"
                                name="filters[brands][<?php echo e($item->id); ?>]"
                                value="<?php echo e($item->id); ?>"
                                <?php if(request('filters.brands.'.$item->id)): echo 'checked'; endif; ?>
                                id="filters-brands-<?php echo e($item->id); ?>">
                            <label for="filters-brands-<?php echo e($item->id); ?>" class="checkbox-label">
                                <img src="<?php echo e($item->makeThumbnail('280x140')); ?>" alt="<?php echo e($item->title); ?>">
                            </label>
                        </button>
                    </div>
                <?php endif; ?>

                <?php if(auth()->user()->role == 'продавец'): ?>
                    <div class="info">
                        <button class="button-filter" type="submit">
                        <input
                            class="filter"
                            name="filters[brands][<?php echo e($item->id); ?>]"
                            value="<?php echo e($item->id); ?>"
                            <?php if(request('filters.brands.'.$item->id)): echo 'checked'; endif; ?>
                            id="filters-brands-<?php echo e($item->id); ?>">
                        <label for="filters-brands-<?php echo e($item->id); ?>" class="checkbox-label">
                            <h3 class="category-title"><?php echo e($item->title); ?></h3>
                        </label>
                        </button>
                    </div>
                    <form method="post" action="<?php echo e(route('removeBrand', $item->id)); ?>">
                        <?php echo csrf_field(); ?>
                        <button type="submit" class="btn-admin">Удалить брэнд</button>
                    </form>

                    <button
                        onclick="window.location.href = '<?php echo e(route('editBrand', $item->id)); ?>'"
                        type="button"
                        class="btn-admin">
                        Редактировать брэнд
                    </button>
                <?php endif; ?>

            <?php elseif(auth()->guard()->guest()): ?>
                <div class="image">
                    <button class="button-filter" type="submit">
                        <input
                            class="filter"
                            name="filters[brands][<?php echo e($item->id); ?>]"
                            value="<?php echo e($item->id); ?>"
                            <?php if(request('filters.brands.'.$item->id)): echo 'checked'; endif; ?>
                            id="filters-brands-<?php echo e($item->id); ?>">
                        <label for="filters-brands-<?php echo e($item->id); ?>" class="checkbox-label">
                            <img src="<?php echo e($item->makeThumbnail('280x140')); ?>" alt="<?php echo e($item->title); ?>">
                        </label>

                    </button>
                </div>
            <?php endif; ?>
        <?php endif; ?>
    </form>
</div>

<script type="module" src="https://unpkg.com/ionicons@7.1.0/dist/ionicons/ionicons.esm.js"></script>
<script nomodule src="https://unpkg.com/ionicons@7.1.0/dist/ionicons/ionicons.js"></script>
</body>
<?php /**PATH E:\PHPStormProjects\market\resources\views/components/brand.blade.php ENDPATH**/ ?>