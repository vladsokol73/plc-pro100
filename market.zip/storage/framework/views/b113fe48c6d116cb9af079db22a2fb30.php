<?php $__env->startSection("title"); ?>
    Добавление категории
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <h1 class="mb-4">Добавить категорию</h1>
    <div class="container">
        <form method="post" action="<?php echo e(route('saveCategory')); ?>" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <div class="form-group" style="margin-top: 10px">
                <input type="text" class="form-control" name="title" placeholder="название категории"
                       required minlength="3" maxlength="35" value="<?php echo e(old('title') ?? ''); ?>">
            </div>
            <button type="submit" class="btn btn-success">Сохранить</button>
        </form>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make("layouts.app", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\work\market\resources\views/category/add.blade.php ENDPATH**/ ?>