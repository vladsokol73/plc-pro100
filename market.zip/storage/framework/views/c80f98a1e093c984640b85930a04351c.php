<?php $__env->startSection("title"); ?>
    <?php echo e($product->title); ?> <?php echo e($product->article); ?> <?php echo e($product->brand->title); ?> купить в розницу и оптом по низкой цене - plc-pro100
<?php $__env->stopSection(); ?>
<head>
    <meta name="description" content="<?php echo e($product->brand->title); ?>, <?php echo e($product->title); ?>, <?php echo e($product->article); ?>, <?php echo e($product->description); ?>">
    <meta name="keywords" content="<?php echo e($product->brand->title); ?>, <?php echo e($product->title); ?>, <?php echo e($product->article); ?>">
</head>

<?php $__env->startSection("content"); ?>
    <form method="post" action="<?php echo e(route('basketAdd', ['id' => $product->id])); ?>">
        <?php echo csrf_field(); ?>
        <section class="product-details">
            <div class="image-slider">
                <img src="<?php echo e($product->makeThumbnail('345x320')); ?>" alt="<?php echo e($product->title); ?>">
            </div>

            <div class="details">
                <h1 class="product-brand"><?php echo e($product->title); ?></h1>
                <p class="product-short-des"><?php echo e($product->description); ?></p>
                <p class="product-sub-heading">Спецификация</p>
                <p>Тип: <?php $__currentLoopData = $product->categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php echo e($category->title); ?>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></p>
                <p>Производитель: <?php echo e($product->brand->title); ?></p>
                <?php if($product->file != null): ?>
                    <p><a href="<?php echo e($product->filePath()); ?>">Документация: </a></p>
                <?php endif; ?>
                <div class="price-btn">
                    <span class="product-price"><?php echo e($product->price); ?></span>
                    
                    



                    
                    
                    
                    
                    
                    
                    
                    
                    
                    

                    <p>
                        <button class="btn cart-btn">В Корзину</button>
                    </p>
                </div>
            </div>
        </section>
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make("layouts.app", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\PHPStormProjects\market\resources\views/product/show.blade.php ENDPATH**/ ?>