<header>
    <nav class="navbar">
        <div class="navbar-container container">
            <input type="checkbox" name="" id="">
            <div class="hamburger-lines">
                <span class="line line1"></span>
                <span class="line line2"></span>
                <span class="line line3"></span>
            </div>
            <a class="brand-logo" href="<?php echo e(route('home')); ?>"><img src="/storage/images/logotip.jpg" class="brand-logo"
                                                                  alt=""></a>
            <div class="nav-items">
                <li>
                    <div class="search">
                        <form class="search" action="<?php echo e(route('catalog')); ?>">
                            <input id="search" name="s" value="<?php echo e(request('s')); ?>" type="search" class="search-box"
                                   placeholder="поиск по названию, артиклу">
                            <button class="search-btn" type="submit">найти</button>
                        </form>
                    </div>
                </li>
                <li><a href="<?php echo e(route('catalog')); ?>">Каталог товаров</a></li>
                <?php if(auth()->guard()->check()): ?>
                    <?php if(auth()->user()->role == "покупатель"): ?>
                        <li><a href="<?php echo e(route('showBrands')); ?>">Бренды</a></li>
                        <li><a href="<?php echo e(route('basket')); ?>"><img src="/storage/images/cart.png" alt=""></a></li>

                    <?php else: ?>
                        <li><a href="<?php echo e(route('sellerCatalog')); ?>">Админ панель</a></li>
                    <?php endif; ?>
                <?php endif; ?>
                <?php if(auth()->guard()->guest()): ?>
                    <li><a href="<?php echo e(route('showBrands')); ?>">Бренды</a></li>
                    <li><a href="<?php echo e(route('basket')); ?>"><img src="/storage/images/cart.png" alt=""></a></li>
                <?php endif; ?>

                <?php if(auth()->guard()->check()): ?>
                    <?php if(auth()->user()->role == "покупатель"): ?>
                        <li><a href="<?php echo e(route('userOrders')); ?>"><img src="/storage/images/user.png" alt=""></a></li>
                    <?php else: ?>
                        <li><a href="<?php echo e(route('sellerProfile')); ?>"><img src="/storage/images/user.png" alt=""></a></li>

                    <?php endif; ?>
                    <form id="logout" method="post" action="<?php echo e(route("logout")); ?>" class="button-logout">
                        <?php echo csrf_field(); ?>
                        <li><a href="#" onclick="document.getElementById('logout').submit()">
                                <img src="/storage/images/logout.png" alt="">
                            </a></li>
                    </form>
                <?php elseif(auth()->guard()->guest()): ?>
                    <li><a href="<?php echo e(route('login')); ?>">Войти</a></li>
                    <li><a href="<?php echo e(route('register')); ?>">Зарегистрироваться</a></li>
                <?php endif; ?>
                <li><a class="a-contact" href="<?php echo e(route('contact')); ?>">Задать вопрос</a></li>
            </div>
        </div>
    </nav>

    
    

    
    
    
    

    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    


    <ul class="links-container">
        <navigation>
            <menu>
                <menuitem id="categories">
                    <button class='glowing-btn'><span class='glowing-txt'>К<span
                                class='faulty-letter'>А</span>ТЕГОРИИ</span></button>
                    <menu>
                        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($category->parent_id == null): ?>

                                <menuitem>
                                    <a href="<?php echo e(route('catalog', $category)); ?>"><?php echo e($category->title); ?></a>
                                    <menu>
                                        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subcategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php if($subcategory->parent_id == $category->id): ?>
                                                <menuitem><a
                                                        href="<?php echo e(route('catalog', $subcategory)); ?>"><?php echo e($subcategory->title); ?></a>
                                                </menuitem>
                                            <?php endif; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </menu>
                                </menuitem>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </menu>
                </menuitem>
            </menu>
        </navigation>
    </ul>
</header>
<?php /**PATH E:\PHPStormProjects\market\resources\views/inc/header.blade.php ENDPATH**/ ?>