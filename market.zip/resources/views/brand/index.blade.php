@extends("layouts.app")

@section("title")
    Производители
@endsection
