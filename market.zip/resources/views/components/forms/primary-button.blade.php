<button class="auth-btn" type="submit">
    {{ $slot }}
</button>
