<div class="mt-3 text-pink text-xxs xs:text-xs">
    {{ $slot }}
</div>
