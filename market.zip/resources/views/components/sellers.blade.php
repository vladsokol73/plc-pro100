<body>
<div class="col-md-2">
    <div class="product">
        <div class="image">
                <img src="https://loremflickr.com/500/500">
        </div>

        <div class="info">
            <h3>{{ $item->name }}</h3>
            </div>
        </div>
    </div>
</body>
