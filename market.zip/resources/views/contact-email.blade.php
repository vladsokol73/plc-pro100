<div>
    <h1>Обратная связь номер: {{ $contactNum }}</h1>
    <h1>Создана: {{ $contactDate }}</h1>
    <div>
        <h2>Имя: {{ $contactName }}</h2>
        <h2>Почта: {{ $contactMail }}</h2>
        <h2>Телефон: {{ $contactPhone }}</h2>
        <h2>Сообщение: {{ $contactMessage }}</h2>
    </div>
</div>
