# Installation

- composer install
- php artisan storage:link
- php artisan migrate

# Deploy
