module.exports = {
    plugins: {
        tailwindcss: {},
        autoprefix: {},
    },
};
