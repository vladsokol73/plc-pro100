<?php

return [
    'allowed_size' => [
        '345x320',
        '280x140'
    ]
];
